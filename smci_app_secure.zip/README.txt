SMCI secure application package.
Place your application files here.